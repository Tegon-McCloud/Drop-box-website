
<nav class="nav-bar">
	<h1>File Storage</h1>
	<a href="signup.php">Sign up</a>
	<a href="login.php">Log in</a>
	<a href="files.php">Files</a>
</nav>